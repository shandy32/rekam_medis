<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class transaksi extends CI_Controller {

	public function __construct()
	{
		parent::__construct();

		$this->load->model('Kode_t');
	}	

	public function index()
	{
		$data['record'] = $this->db->get('tb_tiket')->result();
		$data['kode'] = $this->Kode_t->kode();

		$data['content'] = $this->db->get('tb_transaksi');
		$this->load->view('admin/transaksi',$data);


	} 

	public function tampil()
	{
		$data['record'] = $this->db->get('tb_tiket')->result();
		$data['kode'] = $this->Kode_t->kode();

		$data['content'] = $this->db->get('tb_transaksi');
		$this->load->view('admin/data_transaksi',$data);


	} 



	public function action_add()
	{
		$tgl=date('Ymd'); 
		$data = array(
			'kd_transaksi' => $this->input->post('kd_transaksi'),
			'nama_wahana' => $this->input->post('nama_wahana'),
			'tanggal' => $tgl,
			'harga' => $this->input->post('harga'),
			'jumlah' => $this->input->post('jumlah'),
			'total' => $this->input->post('total'),
			'kembalian' => $this->input->post('kembalian')
			 );

		$this->db->insert('tb_transaksi',$data);
		$this->session->set_flashdata('simpan','Berhasil Disimpan');		
		redirect(base_url('admin/transaksi'),'refresh');
	}

	public function delete($id = NULL)
	{
		$this->db->where('id', $id);
		$this->db->delete('tb_transaksi');
		$this->session->set_flashdata('hapus','Berhasil Dihapus');
		redirect('admin/transaksi','refresh');
	}

	
	public function read($id = NULL)
	{
		$this->db->where('id', $id);

		$data['content'] = $this->db->get('tb_transaksi');
		$this->load->view('admin/data_transaksi', $data);
		
	}

	public function update($id = NULL)
	{
		$this->db->where('id', $id);
		$data['content'] = $this->db->get('tb_transaksi');	

		$this->load->view('admin/update_transaksi', $data);
	}

	public function action_update($id='')
	{
		$data = array(
			'kd_transaksi' => $this->input->post('kd_transaksi'),
			'nama_wahana' => $this->input->post('nama_wahana'),
			'harga_transaksi' => $this->input->post('harga_transaksi')
			
			 );
		
		$this->db->where('id', $id);
		$this->db->update('tb_transaksi', $data);
		$this->session->set_flashdata('update','Berhasil Diupdate');
		redirect('admin/transaksi','refresh');	
	}


}