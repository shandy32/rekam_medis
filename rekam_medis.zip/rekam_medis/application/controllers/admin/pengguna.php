<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class pengguna extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
	}	

	public function index()
	{
		$data['content'] = $this->db->get('tb_pengguna');
		$this->load->view('admin/data_pengguna',$data);
	} 

	public function add()
	{
		$this->load->view('admin/add_pengguna');
	}	


	public function action_add()
	{

		$data = array(
			'nama_pengguna' => $this->input->post('nama_pengguna'),
			'jenis_kelamin' => $this->input->post('jenis_kelamin'),
			'no_hp' => $this->input->post('no_hp'),
			'jabatan' => $this->input->post('jabatan'),
			'username' => $this->input->post('username'),
			'password' => md5($this->input->post('password'))
			 );

		$this->db->insert('tb_pengguna',$data);
		$this->session->set_flashdata('simpan','Berhasil Disimpan');		
		redirect(base_url('admin/pengguna'),'refresh');
	}

	public function delete($kd_pengguna = NULL)
	{
		$this->db->where('kd_pengguna', $kd_pengguna);
		$this->db->delete('tb_pengguna');
		$this->session->set_flashdata('hapus','Berhasil Dihapus');
		redirect('admin/pengguna','refresh');
	}

	
	public function read($kd_pengguna = NULL)
	{
		$this->db->where('kd_pengguna', $kd_pengguna);

		$data['content'] = $this->db->get('tb_pengguna');
		$this->load->view('admin/data_pengguna', $data);
		
	}

	public function update($kd_pengguna = NULL)
	{
		$this->db->where('kd_pengguna', $kd_pengguna);
		$data['content'] = $this->db->get('tb_pengguna');	

		$this->load->view('admin/update_pengguna', $data);
	}

	public function action_update($kd_pengguna='')
	{
		$data = array(
			'nama_pengguna' => $this->input->post('nama_pengguna'),
			'jenis_kelamin' => $this->input->post('jenis_kelamin'),
			'no_hp' => $this->input->post('no_hp'),
			'jabatan' => $this->input->post('jabatan'),
			'username' => $this->input->post('username'),
			'password' => md5($this->input->post('password'))
			 );
		
		$this->db->where('kd_pengguna', $kd_pengguna);
		$this->db->update('tb_pengguna', $data);
		$this->session->set_flashdata('update','Berhasil Diupdate');
		redirect('admin/pengguna','refresh');	
	}


}