<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class tiket extends CI_Controller {

	public function __construct()
	{
		parent::__construct();

		$this->load->model('Kode_m');
	}	

	public function index()
	{
		$data['content'] = $this->db->get('tb_tiket');
		$this->load->view('admin/data_tiket',$data);
	} 

	public function add()
	{
		$data['kode'] = $this->Kode_m->kode();
		$this->load->view('admin/add_tiket',$data);

	}	


	public function action_add()
	{

		$data = array(
			'kd_tiket' => $this->input->post('kd_tiket'),
			'nama_wahana' => $this->input->post('nama_wahana'),
			'harga_tiket' => $this->input->post('harga_tiket')
			
			 );

		$this->db->insert('tb_tiket',$data);
		$this->session->set_flashdata('simpan','Berhasil Disimpan');		
		redirect(base_url('admin/tiket'),'refresh');
	}

	public function delete($id = NULL)
	{
		$this->db->where('id', $id);
		$this->db->delete('tb_tiket');
		$this->session->set_flashdata('hapus','Berhasil Dihapus');
		redirect('admin/tiket','refresh');
	}

	
	public function read($id = NULL)
	{
		$this->db->where('id', $id);

		$data['content'] = $this->db->get('tb_tiket');
		$this->load->view('admin/data_tiket', $data);
		
	}

	public function update($id = NULL)
	{
		$this->db->where('id', $id);
		$data['content'] = $this->db->get('tb_tiket');	

		$this->load->view('admin/update_tiket', $data);
	}

	public function action_update($id='')
	{
		$data = array(
			'kd_tiket' => $this->input->post('kd_tiket'),
			'nama_wahana' => $this->input->post('nama_wahana'),
			'harga_tiket' => $this->input->post('harga_tiket')
			
			 );
		
		$this->db->where('id', $id);
		$this->db->update('tb_tiket', $data);
		$this->session->set_flashdata('update','Berhasil Diupdate');
		redirect('admin/tiket','refresh');	
	}


}